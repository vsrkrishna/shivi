﻿using BookEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookPL
{
    class BookPL
    {
        static void Main(string[] args)
        {
           
                          PrintMenu();
            }
            private static void PrintMenu()
            {
                string choice1;
                do
                {
                    Console.WriteLine("\n***********Hospital Management System*********");
                    Console.WriteLine("1.Add Book");
                    Console.WriteLine("2.Get All Book Details");
                    int choice = Int32.Parse(Console.ReadLine());
                    switch (choice)

                    {
                        case 1:
                            AddBook();
                            break;
                            // case 2:
                            //   ListPatient();
                            // break;
                    }
                    Console.WriteLine("Do You Want to Continue(y/n)?");
                    choice1 = Console.ReadLine();


                }
                while (choice1 == "y");
                Console.ReadLine();
            }
            private static void AddBook()
            {
                try
                {
                    Book newBook = new Book();
                    Console.WriteLine("Enter book Id:");
                    newBook.BookID = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter book name:");
                    newBook.BookName = Console.ReadLine();
                    Console.WriteLine("Enter price:");
                    newBook.Price = Convert.ToInt32(Console.ReadLine());
                    bool bookAdded = BookBLL.BookBLL.AddBookBL(newBook);
                    if (bookAdded)
                        Console.WriteLine("book added");
                    else
                        Console.WriteLine("book not added");
                }
                catch (BookException.BmsException ex)
                {
                    Console.WriteLine(ex.Message);
                }



            }
        }
    }

