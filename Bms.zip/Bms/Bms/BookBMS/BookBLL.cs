﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookDAL;
using BookEntity;
using BookException;

namespace BookBLL
{
    public class BookBLL
    {
        private static bool ValidateBook(Book Book)
        {
            StringBuilder sb = new StringBuilder();
            bool validBook = true;
            if (Book.BookID <= 0)
            {
                validBook = false;
                sb.Append(Environment.NewLine + "Invalid Patient ID");

            }
            if (Book.BookName == string.Empty)
            {
                validBook = false;
                sb.Append(Environment.NewLine + "Book Name Required");

            }
            if (Book.Price > 0)
            {
                validBook = false;
                sb.Append(Environment.NewLine + "Required Bookprice");
            }
            if (validBook == false)
                throw new BookException.BmsException(sb.ToString());
            return validBook;
        }

        public static bool AddBookBL(Book newBook)
        {
            bool bookAdded = false;
            try
            {
                if (ValidateBook(newBook))
                {
                    BookDAL.BookDAL bookDAL = new BookDAL.BookDAL();
                    bookAdded = bookDAL.AddBookDAL(newBook);
                }
            }
            catch (BookException.BmsException e)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return bookAdded;
        }
    }
}
