﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookEntity
{
    public class Book
    {
        public int BookID { get; set; }
        public string BookName { get; set; }
        public int Price{ get; set; }
    }
}
