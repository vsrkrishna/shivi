﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookEntity;
using BookException;


namespace BookDAL
{
    public class BookDAL
    {
        static List<Book> bookList = new List<Book>();
        public bool AddBookDAL(Book newBook)
        {
            bool bookAdded = false;
            try
            {

                bookList.Add(newBook);
                bookAdded = true;


            }
            catch (Exception ex)
            {
                throw new BookException.BmsException(ex.Message);
            }
            return bookAdded;

        }
    }
}
    

