﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookException
{
    public class BmsException:AccessViolationException
    {
        
            public BmsException() : base() { }

            public BmsException(string message) : base(message) { }

            public BmsException(string message,
                   Exception innerException) : base(message, innerException) { }

        
    }
}
